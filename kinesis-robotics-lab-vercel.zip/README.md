# Kinesis Robotics Lab – Browser-based 3D robot lab (Vite + React + three.js)

Ready for Vercel. Framework: Vite · Build: `npm run build` · Output: `dist` (already set in vercel.json).

## Deploy (auto-deploys on every upload/push)
1. Create a GitHub repo and upload ALL files from this folder to the repo root (drag & drop works on github.com → "uploading an existing file").
2. On vercel.com → Add New → Project → import that repo → Deploy. No settings to change.
   From then on, every commit/upload to the repo redeploys automatically.

Or with the CLI (no GitHub needed):  `npm i -g vercel && vercel --prod` inside this folder.

## Local
npm install && npm run dev
